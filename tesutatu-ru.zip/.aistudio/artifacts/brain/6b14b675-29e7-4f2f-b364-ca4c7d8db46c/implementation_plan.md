# AegisLab Desktop × MK1Ai Productization — 統合アーキテクチャ・監査・実装計画書

本計画書は、既存ワークスペースの読み取り専用監査結果（証拠区分に基づく実態確認）をベースラインとして保全しつつ、**AegisLab Desktop（macOS風ブラウザデスクトップ環境＋Tester専用YouTube Live配信スタジオ）**と**MK1Ai 製品化基盤（Honeypot Management Engine・4段階ライセンス/エンタイトルメント・Developer Group管理・Ed25519オフラインライセンス検証・既存テスター回帰検証）**を一体設計・実装するためのマスタープランである。

---

## User Review & Critical Decisions

> [!IMPORTANT]
> フェーズ1のヒアリングで確認された設計方針と、未回答項目に対する推奨デフォルト設定は以下の通りです。内容をご確認の上、承認（Proceed）または修正指示をお願いします。

- **Confirmed Decision 1（統合スコープ）**: **AegisLab Desktop と MK1Ai 製品化基盤の一体設計**を採用。既存の Phase 2A セキュリティ基盤・設計文書・単体テスト資産を一切破壊せず、macOS風デスクトップ環境上に既存15アプリ＋システムアプリ（Files / Code / Inspector / Settings / Tester）＋MK1Ai 製品化管理コンソールを統合する。
- **Confirmed Decision 2（Honeypot 台数上限と構成基準）**: プラン別上限を **Community/Basic: 2台、Standard: 8台、Pro: 32台、Developer Group/Enterprise: 動的上限（ハードウェア安全閾値連動）** とし、実効上限を `min(license_limit, hardware_safe_limit, admin_policy_limit)` で算出する（8台ハードコードを排除）。
- **Confirmed Decision 3（Offline License & Developer Group 認証方式）**: **Ed25519 公開鍵署名検証＋端末ハードウェア識別（Device Fingerprint）＋単調増加カウンタ（Monotonic Sequence Counter）によるロールバック防止**を採用。秘密署名鍵はクライアント側に一切保持しない。
- **Recommended Default 4（Tester 統合・YouTube Live 配信検証スコープ）**: **既存テスターを無改変で保全しつつ、製品化検証ハーネスと Tester 専用 Live Studio（YouTube Live Streaming API 連携＋外部通信ゼロの Mock/Test Mode 分離）を統合**する。

---

## 1. Overview & Core Concept

### 1.1 現在の実装ベースラインと証拠区分監査（Read-Only Audit Baseline）

提示されたベースライン報告と現在のリポジトリ実態を照合し、以下の7段階の証拠区分（`VERIFIED_BY_EXECUTION` / `STATICALLY_VERIFIED` / `DESIGN_ONLY` / `ESTIMATED` / `UNVERIFIED` / `NOT_TESTED` / `FAILED`）で厳密に分類した。

| 監査領域 | 現在の実態・検証内容 | 証拠区分 |
| :--- | :--- | :--- |
| **AegisLab Phase 2A コア & 14設計文書** | 既存14設計文書の SHA-256（全64文字）完全一致、および Phase 2A 単体テスト（15テストケース＋適応制御・音声/TTS・HTML安全性テスト）の実装を確認。 | `VERIFIED_BY_EXECUTION` |
| **SafetyGuard & 必須11安全機構ロック** | 空きRAM（目標200MiB / 緊急停止180MiB）、プロセスRSS（250MiB以下）、空きDisk（目標800MiB / 緊急停止600MiB）のアプリ内閾値ガードと11必須安全機構のOFF拒否を確認。 | `VERIFIED_BY_EXECUTION` |
| **BigInt パケットカウンタ & 仮想ボットモデル** | $1 \sim 10^{16}$（1京）までの丸め誤差ゼロ整数演算、および理論値・シミュレーション値・実測値の5区分分離を確認。 | `VERIFIED_BY_EXECUTION` |
| **RedactionEngine（14カテゴリ Fail-Closed）** | 合成ベクタを用いた14カテゴリ機密トークン置換、および例外注入時の公開出力ブロック（Fail-Closed）を確認。 | `VERIFIED_BY_EXECUTION` |
| **MK1Ai 本体（248 PASS / 22 SKIPPED / C 3/3 PASS / REG-01〜09）** | 現ワークスペース内には設計文書（`SYSTEM_ARCHITECTURE.md` 等）での参照記述のみが存在し、`MK1Ai-main` 実ファイルツリー（Cテスト、PyTorch推論、REG-01〜REG-09コード本体）はワークスペース外にあるため、報告書記載の数値は独立検証前の外部参照情報として扱う。 | `UNVERIFIED`（外部参照・アダプタ境界で保全） |
| **XDP / eBPF 9段階パイプライン** | Stage 3（Linux カーネル存在確認）のみ読み取り専用で確認。Stage 1〜2、4〜9（`*.bpf.c` ビルド・ロード・NICアタッチ・PASS/DROP実測）は未実行。 | `DESIGN_ONLY` / `NOT_TESTED` |
| **実カーネル nftables / 実PyTorch / PQC / QKD** | 実カーネルへの `nft` ルール適用、実PyTorch重み推論、ML-KEM-768 / X25519 / Ed25519 のネイティブC/ハードウェア実行、QKD実機接続は未実行。 | `NOT_TESTED` |
| **YouTube Live 実配信 & RTMPS 送信** | 現時点ではエンドポイント文字列のオフラインマスク保持（`CONFIGURED_OFFLINE_NO_CONNECTION`）のみ実装。OAuth・Broadcast/Stream API・専用Canvasキャプチャはこれから統合実装する。 | `NOT_CONNECTED` |

### 1.2 既存修正の残存リスクと重大検証事項の整理（P0 / P1 監査）

1. **Kill Switch と Quorum（イベント単位の管理者承認）**:
   - `execute_kill_switch()` が無条件実行やリプレイで悪用されないよう、イベントID・タイムスタンプ・対象スコープに紐づく管理者承認トークン（Quorum / Approval Receipt）が揃わない限り実遮断を発火させず、CORE 自己防衛（Fail-Closed 隔離維持）のみを先行させる設計とする。
2. **CORE 安全機能のライセンス非依存性（最重要原則）**:
   - ライセンス期限切れ・署名検証失敗・プラン降格・通信上限超過が発生しても、**CORE 隔離・基本攻撃検知・緊急遮断（Kill Switch）・隔離維持・SafetyGuard は絶対に停止しない**。制限されるのは有料拡張枠（追加ハニーポット台数、商用/拡張OSカタログ、高度分析、高レート帯域）のみとする。
3. **ONI_MODE の単一状態源（Single Source of Truth）**:
   - フロントエンドUI、バックエンドAPI、AdaptivePacketController、Honeypot Manager 間で状態が分裂しないよう、バックエンドの不変ステートマシンを唯一の正規状態源とし、UIは状態スナップショットと監査イベント連鎖（`EvidenceRecorder`）のみを購読する。
4. **暗号プリミティブ・SessionRatchet・QKD と PQC の厳密な区別**:
   - Python/Node.js メモリ空間における鍵破棄（ゼロ化）の言語ランタイム上の限界（GCによるコピー残存可能性）を明記し、PQC（ML-KEM-768 等の耐量子計算機暗号アルゴリズム）と QKD（物理量子鍵配送ハードウェア）を混同せず別区分として管理・表示する。
5. **CSP Nonce・XSS・パストラバーサル・特殊ファイル拒否・Worker 競合**:
   - Files アプリおよび Upload Analyzer では、ルート境界検証・シンボリックリンク拒否・FIFO/デバイスファイル等の特殊ファイル拒否（`stat.S_ISREG` 強制）・走査件数上限（DoS防止）・ファイル全体SHA-256検証を強制する。

---

## 2. User Experience & Visual Design

### 2.1 Key User Flows

1. **AegisLab Desktop（macOS風ワークスペース操作）**:
   - 上部 **Menu Bar**（アクティブアプリ名、システム状態、ライセンスプラン表示、Spotlight検索トリガー、Control Center、Notification Center、時計）と下部 **Dock**、中央のマルチウィンドウ **Desktop Viewport** で構成。
   - **Window Manager** により複数ウィンドウのドラッグ移動、8方向リサイズ、最小化（Dock格納）、最大化、フォーカス時のZ-index最前面化、**Mission Control**（全ウィンドウ俯瞰）、**Launchpad**（全20アプリのグリッド起動）、**Spotlight**（インクリメンタル検索起動）が即座に動作する。
2. **MK1Ai Productization Suite（Honeypot / OS / License / Developer Group 管理）**:
   - ハニーポット構成画面で Outer（表層囮）と Inner（内部高対話環境）の台数・OS・バージョン・CPU/RAM/Storage割当・仮想ネットワークを動的に構成し、`min(license_limit, hardware_safe_limit, admin_policy_limit)` の計算根拠をリアルタイムで確認できる。
   - ライセンス＆プラン画面で Community/Basic・Standard・Pro・Developer Group/Enterprise の4プラン比較、オフラインライセンス署名検証、単調カウンタによるロールバック検知、Developer Group のグループ作成・メンバー権限付与・失効・監査ログ追跡を実行できる。
3. **Tester 専用 Live Studio（OBS不要のYouTube Live 配信 & テストモード）**:
   - Tester ウィンドウ内の **Live Studio** タブで、**Tester 専用 Output Canvas**（他アプリやFiles、秘密情報を一切含まないホワイトリスト描画領域）のリアルタイムプレビューを表示。
   - **Test Mode（外部通信ゼロの Mock YouTube API & Fake Ingest Sink）**と **Live Mode（Google OAuth 2.0 + 公式 YouTube Live Streaming API 連携）** を明確に分離し、Stream Status が `active` になるまで LIVE 移行をロックする安全フローを提供する。

### 2.2 Visual Identity & Theme

- **Aesthetic Direction**: macOS Sequoia / Sonoma の精密なデスクトップ操作感と、ハイセキュリティ・オペレーションセンターの視認性を融合したダーク・プロフェッショナルUI（Control Center から Light / Dark テーマ切替対応）。
- **Color Palette & Mood**:
  - 60% Dominant Neutral Canvas: Deep Obsidian Slate (`#0B0F19` / Light時 `#F8FAFC`)
  - 30% Structural Window Surfaces: Translucent Charcoal Slate (`#111827` / `rgba(17, 24, 39, 0.88)` + `1px solid rgba(255, 255, 255, 0.10)`)
  - 10% Semantic & Action Accents: Primary System Blue (`#3B82F6`), Nominal Emerald (`#10B981`), Warning Amber (`#F59E0B`), Critical Crimson (`#EF4444`)
- **Typography & Hierarchy**:
  - Display & Window Titles: `Plus Jakarta Sans` (SemiBold 600 / Bold 700)
  - UI Body & Controls: `DM Sans` (Regular 400 / Medium 500)
  - Telemetry, BigInt Counters, Hashes & Code: `JetBrains Mono` (`font-variant-numeric: tabular-nums` 厳守)
- **Layout & Anti-Slop Discipline**:
  - 1440px デスクトップ基準のフルビューポート設計。カード内カードの入れ子や装飾的な左太線（`border-l-4`）、ピル型バッジの乱用を排し、クリーンな1pxヘアライン境界とタイポグラフィ階層（`·` 区切りメタデータ）で高密度情報を整理する。

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Honeypot Management Engine の動的上限と Outer / Inner 階層設計
- **Chosen Approach**: 固定8台制限を撤廃し、実効上限を `effective_max_honeypots = min(license_plan_limit, hardware_safe_limit, admin_policy_limit)` として動的算出する。各ノードは `tier: "OUTER" | "INNER"`、個別OSイメージ、CPU/RAM/Storage割当、個別隔離（Quarantine）、スナップショット自動復旧、構成バックアップ/復元（署名検証付きJSON）を持つ。
- **Why**: ホストの空きRAM（SafetyGuard閾値）や契約プランに応じて安全にスケールさせつつ、OuterからInnerへの侵入経路分析と個別隔離を両立するため。
- **Alternatives Considered**: 8台固定配列による管理は、Enterprise用途や低リソース端末の双方で柔軟性を欠くため不採用。

### Decision 2: 4段階ライセンスプランと CORE 安全機能の非停止保証
- **Chosen Approach**:
  - **Community / Basic**: ハニーポット最大2台、標準OSカタログ（MK1Ai Secure Linux + Alpine Minimal）、帯域上限 100 Mbps、CORE隔離・基本検知・緊急遮断は100%有効。
  - **Standard**: ハニーポット最大8台、標準Linux複数バージョン選択、帯域上限 1 Gbps、基本レポート出力。
  - **Pro**: ハニーポット最大32台、Outer/Innerカスタムトポロジ、カスタムOSイメージ登録（署名検証必須）、帯域上限 10 Gbps、高度DPI/XDP分析。
  - **Developer Group / Enterprise**: ハニーポット動的上限（HW許容最大）、全OSカタログ＆カスタムビルド仕様、Developer Group 権限委譲・ライセンス発行/失効管理、エアギャップ用オフラインライセンス発行。
- **Why**: セキュリティ製品の倫理的・技術的必須要件として、ライセンス状態に関わらずホスト保護と緊急遮断（CORE機能）を常時維持するため。

### Decision 3: Ed25519 Offline License Engine と Developer Group 権限のサーバー側強制
- **Chosen Approach**: Node.js `crypto` 標準モジュール（Ed25519）を用い、サーバー側に検証用公開鍵のみを配置（クライアントへの秘密鍵埋め込み禁止）。ライセンストークンには `license_id`, `plan`, `device_fingerprint`, `issued_at`, `expires_at`, `monotonic_seq`, `entitlements`, `revocation_epoch` を含め、署名検証＋単調増加シーケンス番号チェックにより古いライセンスへのロールバック攻撃を阻止する。Developer Group の最上位権限はクライアント自己申告ヘッダ等を一切信用せず、検証済み署名トークンとサーバー側 RBAC 台帳で強制する。
- **Why**: エアギャップ環境でも外部認証サーバーなしで改ざん・巻き戻し・なりすましを数学的に検知できるため。

### Decision 4: Tester 専用 Canvas ストリーミングと Test Mode / Live Mode の厳格分離
- **Chosen Approach**: Tester アプリ内に `Dedicated Stream Canvas (1280x720 / 1920x1080)` を設け、描画対象をホワイトリスト化されたテスト指標（パケット推移グラフ、ボット統計、模擬デバイスメトリクス、検証ステータス、ユーザー承認済み説明テキスト）のみに限定する。さらに出力前に `RedactionEngine` でテキスト検査を行い、プレビュー画面と送信ストリームが100%同一Canvasを参照する構造とする。
- **Why**: AegisLab Desktop 全体や Files、OAuth Token、Stream Key が配信映像に映り込む事故を構造的にゼロにするため。

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### 4.1 Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                        AEGISLAB DESKTOP (macOS-Style Browser Shell)                     │
│  ┌──────────────────┐  ┌──────────────────────────┐  ┌───────────────────────────────┐  │
│  │ Menu Bar / Dock  │  │ Window Manager / Mission │  │ Spotlight / Launchpad /       │  │
│  │ Control Center   │  │ Control / Focus & Z-Order│  │ Notification Center           │  │
│  └────────┬─────────┘  └────────────┬─────────────┘  └───────────────┬───────────────┘  │
│           └─────────────────────────┼────────────────────────────────┘                  │
│                                     ▼                                                   │
│  ┌───────────────────────────────────────────────────────────────────────────────────┐  │
│  │                     20 Integrated Desktop Applications                            │  │
│  │  • 15 Core Aegis Apps (Overview, Packet Sim, Adaptive Ctrl, Bot Lab, Virtual Env, │  │
│  │    Decoys/Honeypots, Security Events, DPI/XDP, Isolation, Privacy, TTS, Mixer,    │  │
│  │    Subtitle, Device Monitor, Audit & Settings)                                    │  │
│  │  • 5 System & Productization Apps:                                                │  │
│  │    [Aegis Files (RO)] [Aegis Code] [File Inspector] [MK1Ai License/DevGroup]      │  │
│  │    [Aegis Tester + Built-in YouTube Live Studio (Dedicated Whitelisted Canvas)]   │  │
│  └──────────────────────────────────┬────────────────────────────────────────────────┘  │
└─────────────────────────────────────┼───────────────────────────────────────────────────┘
                                      │ AegisDesktopBridge (Promise + AbortController + CSRF)
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                   UNIFIED BACKEND RUNTIME (Node.js API + Python Core Bridge)            │
│                                                                                         │
│  ┌────────────────────────────┐  ┌───────────────────────────┐  ┌────────────────────┐  │
│  │ CORE Safety & Isolation    │  │ MK1Ai Productization      │  │ Streaming & Tester │  │
│  │ • SafetyGuard (RAM/RSS/DSK)│  │ • HoneypotManager (N-node)│  │ • YouTube Live API │  │
│  │ • KillSwitch + Quorum Gate │  │ • OSImageCatalog & Signer │  │ • OAuth2 PKCE/State│  │
│  │ • RedactionEngine (14-cat) │  │ • LicenseEntitlementEngine│  │ • MockIngestSink   │  │
│  │ • EvidenceRecorder (SHA256)│  │ • DevGroupAdmin & Audit   │  │ • StreamSafetyGate │  │
│  │ • SafeReadOnlyFilesEngine  │  │ • OfflineLicenseVerifier  │  │ • FFmpeg/RTMPS Dry │  │
│  └────────────────────────────┘  └───────────────────────────┘  └────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Data Model & State Strategy

1. **Honeypot Topology & Node Model**:
   - `HoneypotNode`: `{ node_id, name, layer: "OUTER" | "INNER", os_id, os_version, cpu_cores, ram_mib, storage_mib, subnet_cidr, state: "STOPPED" | "RUNNING" | "ISOLATED" | "RECOVERING", image_sha256, signature_verified, auto_recover }`
   - `EffectiveCapacity`: `{ license_limit, hardware_safe_limit, admin_policy_limit, effective_max, current_allocated, core_reserved_ram_mib: 200 }`
2. **License & Entitlement Model**:
   - `LicenseToken`: `{ license_id, plan_tier: "BASIC" | "STANDARD" | "PRO" | "ENTERPRISE", holder_group_id, device_fingerprint, issued_at, expires_at, monotonic_seq, max_honeypots, max_bandwidth_mbps, allowed_os_families, custom_os_allowed, signature_ed25519 }`
   - `CoreSafetyGuarantee`: `{ core_isolation_active: true, kill_switch_ready: true, emergency_bandwidth_reserved_mbps: 10, degraded_mode_reason }`
3. **Developer Group Administration Model**:
   - `DeveloperGroup`: `{ group_id, group_name, tier: "ENTERPRISE", members: [{ user_id, role, added_at }], assigned_quotas: { max_honeypots, max_bandwidth_mbps, allowed_os_ids }, issued_licenses: [...], audit_trail_sha256 }`
4. **Tester Live Studio & Streaming State Machine**:
   - 14の状態（`DISCONNECTED`, `NOT_CONFIGURED`, `AUTH_REQUIRED`, `READY`, `PREVIEW`, `ENCODING`, `CONNECTING`, `TESTING`, `LIVE`, `STOPPING`, `STOPPED`, `ERROR`, `NOT_ELIGIBLE`, `NOT_AVAILABLE`）を厳格に管理。
   - Stream Key や OAuth Token はサーバー側メモリ（またはセキュアストア）のみで一時保持し、フロントエンドJS・HTML・DOM・ログ・永続ファイルには一切露出させない。

### 4.3 Interactive Component & State Mapping (Priority P0–P7 Roadmap)

| 優先度 | フェーズ領域 | 実装・検証の具体的内容 |
| :---: | :--- | :--- |
| **P0** | **既存基盤保全 & 証拠監査** | 既存14設計文書および Phase 2A Pythonモジュール・テストスイートを100%無破壊で維持。`EvidenceRecorder` のSHA-256ハッシュ連鎖監査ログと `RedactionEngine` を全APIへ接続。 |
| **P1** | **CORE隔離 & Kill Switch Quorum** | イベント単位の管理者承認（Quorum Receipt）付き `execute_kill_switch()`、ONI_MODE 単一状態源化、CORE緊急通信帯域と一般ライセンス帯域の分離、SafetyGuard（空きRAM 180MiB / RSS 250MiB / 空きDisk 600MiB）常時強制。 |
| **P2** | **Honeypot Management Engine** | 固定8台制限の撤廃、`min(license, hardware, policy)` 動的上限計算、Outer/Inner 構成変更、個別起動・停止・隔離・自動復旧、署名付き構成バックアップ＆復元。 |
| **P3** | **OSイメージ管理 & カスタマイズ** | MK1Ai Secure Linux（デフォルト・未構築明示）、Alpine/Debian Minimal、Windows（リソース/ライセンス要件判定）、カスタムOS登録、SHA-256＋Ed25519署名検証、7段階プリフライト状態遷移。 |
| **P4** | **License & Entitlement Engine** | Community/Basic・Standard・Pro・Developer Group/Enterprise の4プラン制御、Ed25519 オフラインライセンス検証、端末識別・有効期限・単調増加カウンタによるロールバック防止、期限切れ時のCORE保護維持。 |
| **P5** | **Developer Group Administration** | グループ作成、メンバー追加/削除、プラン割当、ライセンス発行/失効、OS利用権限・ハニーポット上限・帯域上限管理、クライアント自己申告拒否（サーバー署名検証強制）、全管理操作の監査記録。 |
| **P6** | **AegisLab Desktop & Tester Live Studio** | macOS風デスクトップ（Menu Bar, Dock, Window Manager, Mission Control, Launchpad, Spotlight, Files RO, Code Viewer, Inspector）、Tester専用Canvas、YouTube Live API + OAuth 2.0 PKCE/State、外部通信ゼロのTest Modeハーネス。 |
| **P7** | **機能別・プラン別回帰試験 & 出荷判定** | Python単体テストスイート＋Node.js統合APIテスト＋UI検証を実行し、各項目を7段階の証拠区分（`VERIFIED_BY_EXECUTION` 等）で最終レポートに出力。 |
