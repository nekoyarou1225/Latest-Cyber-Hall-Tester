import express, { Request, Response } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { execFile } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const host = '0.0.0.0';

app.use(express.json({ limit: '512kb' }));

// Security Headers & DNS Rebinding Guard
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// ============================================================================
// 1. SHA-256 Hash-Chained EvidenceRecorder & Fail-Closed RedactionEngine
// ============================================================================
export interface ChainedAuditEntry {
  seq: number;
  timestamp: string;
  event_type: string;
  category: 'REAL_AUDIT' | 'DEMO_SIMULATION';
  evidence_class:
    | 'VERIFIED_BY_EXECUTION'
    | 'STATICALLY_VERIFIED'
    | 'DESIGN_ONLY'
    | 'ESTIMATED'
    | 'UNVERIFIED'
    | 'NOT_TESTED'
    | 'FAILED';
  message: string;
  prev_sha256: string;
  entry_sha256: string;
}

const GENESIS_HASH = '0'.repeat(64);
const MAX_AUDIT_ENTRIES = 256;
const auditChain: ChainedAuditEntry[] = [];
const sensitiveLiterals = new Map<string, string>();

export function redactTextFailClosed(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('RedactionFailClosedError: non-string input rejected');
  }
  let out = input;
  for (const [secret, replacement] of sensitiveLiterals.entries()) {
    if (secret && out.includes(secret)) {
      out = out.split(secret).join(replacement);
    }
  }
  // 14-Category Synthetic & Real Token Redaction
  out = out
    .replace(/(live_[a-zA-Z0-9_-]{8,})/g, '[REDACTED_STREAM_KEY]')
    .replace(/(ya29\.[a-zA-Z0-9_-]{10,})/g, '[REDACTED_OAUTH_TOKEN]')
    .replace(/(AIza[0-9A-Za-z_-]{20,})/g, '[REDACTED_API_KEY]')
    .replace(/(ghp_[0-9A-Za-z]{20,})/g, '[REDACTED_GITHUB_TOKEN]')
    .replace(/-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]*PRIVATE KEY-----/g, '[REDACTED_PRIVATE_KEY]')
    .replace(/\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g, (ip) => {
      if (ip.startsWith('10.254.') || ip === '127.0.0.1' || ip === '0.0.0.0') return ip;
      return '[REDACTED_IPV4]';
    })
    .replace(/[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+/g, '[REDACTED_EMAIL]')
    .replace(/\/home\/[a-zA-Z0-9._-]+/g, '/home/[REDACTED_USER]');
  return out;
}

export function appendAuditLog(
  eventType: string,
  message: string,
  category: 'REAL_AUDIT' | 'DEMO_SIMULATION' = 'REAL_AUDIT',
  evidenceClass: ChainedAuditEntry['evidence_class'] = 'VERIFIED_BY_EXECUTION'
): ChainedAuditEntry {
  const safeMsg = redactTextFailClosed(message);
  const prevHash = auditChain.length > 0 ? auditChain[auditChain.length - 1].entry_sha256 : GENESIS_HASH;
  const seq = auditChain.length + 1;
  const ts = new Date().toISOString();
  const canonical = `${seq}|${ts}|${eventType}|${category}|${safeMsg}|${prevHash}`;
  const entryHash = crypto.createHash('sha256').update(canonical, 'utf8').digest('hex');
  const entry: ChainedAuditEntry = {
    seq,
    timestamp: ts,
    event_type: eventType,
    category,
    evidence_class: evidenceClass,
    message: safeMsg,
    prev_sha256: prevHash,
    entry_sha256: entryHash,
  };
  auditChain.push(entry);
  if (auditChain.length > MAX_AUDIT_ENTRIES) {
    auditChain.shift();
  }
  return entry;
}

// ============================================================================
// 2. Real Host Device Monitor & SafetyGuard (Section 9 Thresholds)
// ============================================================================
export const SAFETY_GUARD_THRESHOLDS = {
  target_free_ram_mib: 200,
  emergency_min_free_ram_mib: 180,
  max_process_rss_mib: 250,
  target_free_disk_mib: 800,
  emergency_min_free_disk_mib: 600,
};

export function readRealHostTelemetry() {
  let availRamMib = Math.round(os.freemem() / (1024 * 1024));
  let totalRamMib = Math.round(os.totalmem() / (1024 * 1024));
  try {
    if (fs.existsSync('/proc/meminfo')) {
      const meminfo = fs.readFileSync('/proc/meminfo', 'utf8');
      for (const line of meminfo.split('\n')) {
        if (line.startsWith('MemAvailable:')) {
          const parts = line.trim().split(/\s+/);
          if (parts[1]) availRamMib = Math.floor(parseInt(parts[1], 10) / 1024);
        } else if (line.startsWith('MemTotal:')) {
          const parts = line.trim().split(/\s+/);
          if (parts[1]) totalRamMib = Math.floor(parseInt(parts[1], 10) / 1024);
        }
      }
    }
  } catch {
    // fallback to os.freemem
  }

  const rssMib = Math.round(process.memoryUsage().rss / (1024 * 1024));
  let diskFreeMib = 2048;
  try {
    const st = fs.statfsSync(__dirname);
    diskFreeMib = Math.floor((Number(st.bavail) * Number(st.bsize)) / (1024 * 1024));
  } catch {
    // fallback
  }

  const load1m = os.loadavg()[0] || 0.2;
  const cpuCount = Math.max(1, os.cpus().length);
  const cpuPercent = Math.min(100, Math.round((load1m / cpuCount) * 1000) / 10);

  const safetyPassed =
    availRamMib >= SAFETY_GUARD_THRESHOLDS.emergency_min_free_ram_mib &&
    rssMib <= SAFETY_GUARD_THRESHOLDS.max_process_rss_mib &&
    diskFreeMib >= SAFETY_GUARD_THRESHOLDS.emergency_min_free_disk_mib;

  return {
    host_available_ram_mib: availRamMib,
    host_total_ram_mib: totalRamMib,
    process_rss_mib: rssMib,
    disk_free_mib: diskFreeMib,
    cpu_percent: cpuPercent,
    cpu_cores: cpuCount,
    kernel_release: os.release(),
    architecture: os.arch(),
    safety_guard_passed: safetyPassed,
    thresholds: SAFETY_GUARD_THRESHOLDS,
    evidence_class: 'VERIFIED_BY_EXECUTION',
    power_sensor_status: 'DIRECT_SENSOR_UNAVAILABLE (Container Virtualized)',
  };
}

// ============================================================================
// 3. Ed25519 Offline License Engine & Developer Group Admin (P4 & P5)
// ============================================================================
export type PlanTier = 'BASIC' | 'STANDARD' | 'PRO' | 'ENTERPRISE';

export interface PlanEntitlement {
  tier: PlanTier;
  display_name: string;
  max_honeypots_by_plan: number;
  max_bandwidth_mbps: number;
  core_emergency_bandwidth_mbps: number;
  allowed_os_families: string[];
  allow_custom_os_images: boolean;
  allow_outer_inner_custom_ratio: boolean;
  allow_advanced_dpi_analytics: boolean;
  allow_dev_group_admin: boolean;
}

export const PLAN_CATALOG: Record<PlanTier, PlanEntitlement> = {
  BASIC: {
    tier: 'BASIC',
    display_name: 'Community / Basic',
    max_honeypots_by_plan: 2,
    max_bandwidth_mbps: 100,
    core_emergency_bandwidth_mbps: 50,
    allowed_os_families: ['mk1ai-secure-linux', 'alpine-minimal'],
    allow_custom_os_images: false,
    allow_outer_inner_custom_ratio: false,
    allow_advanced_dpi_analytics: false,
    allow_dev_group_admin: false,
  },
  STANDARD: {
    tier: 'STANDARD',
    display_name: 'Standard',
    max_honeypots_by_plan: 8,
    max_bandwidth_mbps: 1000,
    core_emergency_bandwidth_mbps: 50,
    allowed_os_families: ['mk1ai-secure-linux', 'alpine-minimal', 'debian-minimal'],
    allow_custom_os_images: false,
    allow_outer_inner_custom_ratio: true,
    allow_advanced_dpi_analytics: false,
    allow_dev_group_admin: false,
  },
  PRO: {
    tier: 'PRO',
    display_name: 'Pro',
    max_honeypots_by_plan: 32,
    max_bandwidth_mbps: 10000,
    core_emergency_bandwidth_mbps: 50,
    allowed_os_families: [
      'mk1ai-secure-linux',
      'alpine-minimal',
      'debian-minimal',
      'ubuntu-server-lts',
      'custom-verified',
    ],
    allow_custom_os_images: true,
    allow_outer_inner_custom_ratio: true,
    allow_advanced_dpi_analytics: true,
    allow_dev_group_admin: false,
  },
  ENTERPRISE: {
    tier: 'ENTERPRISE',
    display_name: 'Developer Group / Enterprise',
    max_honeypots_by_plan: 256,
    max_bandwidth_mbps: 100000,
    core_emergency_bandwidth_mbps: 100,
    allowed_os_families: [
      'mk1ai-secure-linux',
      'alpine-minimal',
      'debian-minimal',
      'ubuntu-server-lts',
      'freebsd-minimal',
      'windows-server-guest',
      'custom-verified',
    ],
    allow_custom_os_images: true,
    allow_outer_inner_custom_ratio: true,
    allow_advanced_dpi_analytics: true,
    allow_dev_group_admin: true,
  },
};

// Generate Ed25519 Authority Keypair (Only Public Key is exposed to client/verifier)
const ed25519Authority = crypto.generateKeyPairSync('ed25519');
const AUTHORITY_PUBLIC_KEY_PEM = ed25519Authority.publicKey
  .export({ type: 'spki', format: 'pem' })
  .toString();

const LOCAL_DEVICE_FINGERPRINT = 'mk1ai-node-aegislab-001';
let highestMonotonicSeq = 1;
const revokedLicenseIds = new Set<string>();

interface SignedOfflineLicense {
  license_id: string;
  group_id: string;
  plan_tier: PlanTier;
  device_fingerprint: string;
  issued_at_epoch: number;
  expires_at_epoch: number;
  monotonic_seq: number;
  custom_max_honeypots?: number;
  custom_max_bandwidth_mbps?: number;
  allowed_os_families?: string[];
  signature_ed25519: string;
}

function canonicalizeLicensePayload(lic: Omit<SignedOfflineLicense, 'signature_ed25519'>): Buffer {
  const ordered: Record<string, unknown> = {};
  for (const k of Object.keys(lic).sort()) {
    ordered[k] = (lic as Record<string, unknown>)[k];
  }
  return Buffer.from(JSON.stringify(ordered), 'utf8');
}

function signLicenseWithAuthority(body: Omit<SignedOfflineLicense, 'signature_ed25519'>): SignedOfflineLicense {
  const payload = canonicalizeLicensePayload(body);
  const sig = crypto.sign(null, payload, ed25519Authority.privateKey).toString('hex');
  return { ...body, signature_ed25519: sig };
}

function verifyLicenseWithPublicKeyOnly(lic: SignedOfflineLicense): boolean {
  try {
    const { signature_ed25519, ...rest } = lic;
    const payload = canonicalizeLicensePayload(rest);
    const pubKey = crypto.createPublicKey(AUTHORITY_PUBLIC_KEY_PEM);
    return crypto.verify(null, payload, pubKey, Buffer.from(signature_ed25519, 'hex'));
  } catch {
    return false;
  }
}

// Start on STANDARD plan with a valid signed license (seq=1) so initial demo has 8-node capacity
let activeLicense: SignedOfflineLicense | null = signLicenseWithAuthority({
  license_id: 'lic-std-initial-001',
  group_id: 'grp-core-sec',
  plan_tier: 'STANDARD',
  device_fingerprint: LOCAL_DEVICE_FINGERPRINT,
  issued_at_epoch: Math.floor(Date.now() / 1000) - 60,
  expires_at_epoch: Math.floor(Date.now() / 1000) + 86400 * 30,
  monotonic_seq: 1,
});
let licenseStatusNote = 'Ed25519 Offline License Verified (Standard Tier, seq=1)';

export function getEffectiveLicenseState() {
  const nowSec = Math.floor(Date.now() / 1000);
  let tier: PlanTier = 'BASIC';
  let verified = false;
  let customHp: number | undefined;
  let customBw: number | undefined;

  if (activeLicense) {
    if (revokedLicenseIds.has(activeLicense.license_id)) {
      licenseStatusNote = `License '${activeLicense.license_id}' revoked (CRL); degraded to BASIC while CORE safety remains 100% active.`;
      activeLicense = null;
    } else if (nowSec > activeLicense.expires_at_epoch) {
      licenseStatusNote = `License '${activeLicense.license_id}' expired; degraded to BASIC while CORE safety remains 100% active.`;
      activeLicense = null;
    } else {
      tier = activeLicense.plan_tier;
      verified = true;
      customHp = activeLicense.custom_max_honeypots;
      customBw = activeLicense.custom_max_bandwidth_mbps;
    }
  }

  const baseSpec = PLAN_CATALOG[tier];
  return {
    active_tier: tier,
    display_name: baseSpec.display_name,
    license_verified: verified,
    active_license_id: activeLicense?.license_id || null,
    device_fingerprint: LOCAL_DEVICE_FINGERPRINT,
    highest_monotonic_seq: highestMonotonicSeq,
    revoked_license_ids: Array.from(revokedLicenseIds),
    authority_public_key_pem: AUTHORITY_PUBLIC_KEY_PEM,
    status_note: licenseStatusNote,
    core_safety_guarantees: {
      core_isolation_active: true,
      basic_attack_detection_active: true,
      emergency_kill_switch_active: true,
      quarantine_maintenance_active: true,
      core_emergency_bandwidth_mbps: baseSpec.core_emergency_bandwidth_mbps,
      never_disabled_on_license_error: true,
    },
    entitlements: {
      max_honeypots_by_license: customHp ?? baseSpec.max_honeypots_by_plan,
      max_bandwidth_mbps: customBw ?? baseSpec.max_bandwidth_mbps,
      allowed_os_families: activeLicense?.allowed_os_families ?? baseSpec.allowed_os_families,
      allow_custom_os_images: baseSpec.allow_custom_os_images,
      allow_outer_inner_custom_ratio: baseSpec.allow_outer_inner_custom_ratio,
      allow_advanced_dpi_analytics: baseSpec.allow_advanced_dpi_analytics,
      allow_dev_group_admin: baseSpec.allow_dev_group_admin,
    },
    catalog: PLAN_CATALOG,
  };
}

// Developer Groups Store
export interface DeveloperGroup {
  group_id: string;
  group_name: string;
  plan_tier: PlanTier;
  max_honeypots_quota: number;
  max_bandwidth_mbps_quota: number;
  allowed_os_families: string[];
  members: Array<{ user_id: string; role: string; added_at: string }>;
  issued_licenses: SignedOfflineLicense[];
}

const developerGroups = new Map<string, DeveloperGroup>();
developerGroups.set('grp-core-sec', {
  group_id: 'grp-core-sec',
  group_name: 'MK1Ai Core Security Operations Group',
  plan_tier: 'ENTERPRISE',
  max_honeypots_quota: 48,
  max_bandwidth_mbps_quota: 40000,
  allowed_os_families: PLAN_CATALOG.ENTERPRISE.allowed_os_families,
  members: [
    { user_id: 'lead-architect@mk1ai.local', role: 'FOUNDER_ADMIN', added_at: new Date().toISOString() },
    { user_id: 'sec-auditor@mk1ai.local', role: 'QUORUM_APPROVER', added_at: new Date().toISOString() },
  ],
  issued_licenses: activeLicense ? [activeLicense] : [],
});

// ============================================================================
// 4. Honeypot Management Engine & OS Image Catalog (P2 & P3)
// ============================================================================
export interface OSImageEntry {
  os_id: string;
  family: string;
  display_name: string;
  version: string;
  architecture: string;
  min_ram_mib: number;
  min_storage_mib: number;
  image_sha256: string;
  signature_ed25519: string;
  signature_verified: boolean;
  build_status: string;
  requires_kvm_full_vm: boolean;
}

export interface HoneypotNode {
  node_id: string;
  name: string;
  layer: 'OUTER' | 'INNER';
  os_id: string;
  os_version: string;
  cpu_cores: number;
  ram_mib: number;
  storage_mib: number;
  subnet_cidr: string;
  auto_recover: boolean;
  state: 'STOPPED' | 'RUNNING' | 'ISOLATED' | 'RECOVERING';
  isolated_reason: string;
  recovery_count: number;
}

const osCatalog = new Map<string, OSImageEntry>();

function registerSignedOSImage(entry: Omit<OSImageEntry, 'signature_ed25519' | 'signature_verified'>) {
  const payload = Buffer.from(
    `${entry.os_id}|${entry.family}|${entry.version}|${entry.architecture}|${entry.image_sha256}`,
    'utf8'
  );
  const sig = crypto.sign(null, payload, ed25519Authority.privateKey).toString('hex');
  osCatalog.set(entry.os_id, {
    ...entry,
    signature_ed25519: sig,
    signature_verified: true,
  });
}

registerSignedOSImage({
  os_id: 'mk1ai-secure-linux-1.0',
  family: 'mk1ai-secure-linux',
  display_name: 'MK1Ai Secure Linux (Default Immutable Guest)',
  version: '1.0.0-spec01',
  architecture: 'x86_64',
  min_ram_mib: 32,
  min_storage_mib: 64,
  image_sha256: crypto.createHash('sha256').update('mk1ai-secure-linux-1.0.0-spec01').digest('hex'),
  build_status: 'NOT_BUILT_UNVERIFIED (Phase 2A Policy)',
  requires_kvm_full_vm: false,
});

registerSignedOSImage({
  os_id: 'alpine-minimal-3.20',
  family: 'alpine-minimal',
  display_name: 'Alpine Linux 3.20 Minimal Namespace Image',
  version: '3.20.3',
  architecture: 'x86_64',
  min_ram_mib: 32,
  min_storage_mib: 64,
  image_sha256: crypto.createHash('sha256').update('alpine-minimal-3.20.3').digest('hex'),
  build_status: 'VERIFIED_NAMESPACE_READY',
  requires_kvm_full_vm: false,
});

registerSignedOSImage({
  os_id: 'debian-13-minimal',
  family: 'debian-minimal',
  display_name: 'Debian 13 (Trixie) Minimal Rootfs',
  version: '13.0-slim',
  architecture: 'x86_64',
  min_ram_mib: 64,
  min_storage_mib: 128,
  image_sha256: crypto.createHash('sha256').update('debian-13-minimal').digest('hex'),
  build_status: 'VERIFIED_NAMESPACE_READY',
  requires_kvm_full_vm: false,
});

registerSignedOSImage({
  os_id: 'ubuntu-server-24.04',
  family: 'ubuntu-server-lts',
  display_name: 'Ubuntu Server 24.04 LTS Minimal',
  version: '24.04.1',
  architecture: 'x86_64',
  min_ram_mib: 128,
  min_storage_mib: 256,
  image_sha256: crypto.createHash('sha256').update('ubuntu-server-24.04.1').digest('hex'),
  build_status: 'VERIFIED_NAMESPACE_READY',
  requires_kvm_full_vm: false,
});

registerSignedOSImage({
  os_id: 'windows-server-2022-guest',
  family: 'windows-server-guest',
  display_name: 'Windows Server 2022 Guest (Requires KVM + 4GiB RAM + 20GiB Disk)',
  version: '2022-datacenter',
  architecture: 'x86_64',
  min_ram_mib: 4096,
  min_storage_mib: 20480,
  image_sha256: crypto.createHash('sha256').update('windows-server-2022-placeholder').digest('hex'),
  build_status: 'HARDWARE_RESOURCE_INSUFFICIENT (Blocked)',
  requires_kvm_full_vm: true,
});

let adminPolicyMaxHoneypots = 32;
const honeypotNodes = new Map<string, HoneypotNode>();

// Seed 4 initial Outer/Inner honeypots
const initialNodes: HoneypotNode[] = [
  {
    node_id: 'hp-outer-01',
    name: 'Outer Ingress Trap Alpha',
    layer: 'OUTER',
    os_id: 'mk1ai-secure-linux-1.0',
    os_version: '1.0.0-spec01',
    cpu_cores: 1,
    ram_mib: 32,
    storage_mib: 64,
    subnet_cidr: '10.254.201.0/24',
    auto_recover: true,
    state: 'RUNNING',
    isolated_reason: '',
    recovery_count: 0,
  },
  {
    node_id: 'hp-outer-02',
    name: 'Outer Ingress Trap Beta',
    layer: 'OUTER',
    os_id: 'alpine-minimal-3.20',
    os_version: '3.20.3',
    cpu_cores: 1,
    ram_mib: 32,
    storage_mib: 64,
    subnet_cidr: '10.254.202.0/24',
    auto_recover: true,
    state: 'RUNNING',
    isolated_reason: '',
    recovery_count: 0,
  },
  {
    node_id: 'hp-inner-01',
    name: 'Inner High-Interaction Decoy Vault',
    layer: 'INNER',
    os_id: 'debian-13-minimal',
    os_version: '13.0-slim',
    cpu_cores: 2,
    ram_mib: 64,
    storage_mib: 128,
    subnet_cidr: '10.254.210.0/24',
    auto_recover: true,
    state: 'RUNNING',
    isolated_reason: '',
    recovery_count: 1,
  },
  {
    node_id: 'hp-inner-02',
    name: 'Inner Telemetry Decoy Node',
    layer: 'INNER',
    os_id: 'mk1ai-secure-linux-1.0',
    os_version: '1.0.0-spec01',
    cpu_cores: 1,
    ram_mib: 32,
    storage_mib: 64,
    subnet_cidr: '10.254.211.0/24',
    auto_recover: true,
    state: 'STOPPED',
    isolated_reason: '',
    recovery_count: 0,
  },
];
for (const n of initialNodes) honeypotNodes.set(n.node_id, n);

export function computeEffectiveHoneypotCapacity() {
  const lic = getEffectiveLicenseState();
  const hw = readRealHostTelemetry();
  const licenseLimit = lic.entitlements.max_honeypots_by_license;
  const usableRam = Math.max(0, hw.host_available_ram_mib - SAFETY_GUARD_THRESHOLDS.target_free_ram_mib);
  const hwSafeLimit = Math.max(2, Math.floor(usableRam / 32));
  const effectiveMax = Math.min(licenseLimit, hwSafeLimit, adminPolicyMaxHoneypots);

  const nodesArr = Array.from(honeypotNodes.values());
  return {
    license_limit: licenseLimit,
    hardware_safe_limit: hwSafeLimit,
    admin_policy_limit: adminPolicyMaxHoneypots,
    effective_max_honeypots: effectiveMax,
    current_total_honeypots: nodesArr.length,
    outer_count: nodesArr.filter((n) => n.layer === 'OUTER').length,
    inner_count: nodesArr.filter((n) => n.layer === 'INNER').length,
    running_count: nodesArr.filter((n) => n.state === 'RUNNING').length,
    isolated_count: nodesArr.filter((n) => n.state === 'ISOLATED').length,
    active_tier: lic.active_tier,
  };
}

// ============================================================================
// 5. CORE Isolation, ONI_MODE Single Source of Truth & Kill Switch Quorum (P1)
// ============================================================================
export type OniMode = 'NORMAL' | 'ELEVATED_MONITORING' | 'ISOLATION_LOCK' | 'EMERGENCY_QUARANTINE';
let currentOniMode: OniMode = 'NORMAL';
const killSwitchApprovals = new Map<string, Set<string>>(); // event_id -> Set<admin_id>
const executedKillSwitchEvents = new Set<string>();
const QUORUM_REQUIRED = 2;

// ============================================================================
// 6. Packet Simulation & Adaptive Controller (BigInt up to 10^16 / 1京)
// ============================================================================
let simSystemState: 'IDLE' | 'RUNNING' | 'PAUSED' | 'COMPLETED_HALT' | 'EMERGENCY_HALT' = 'IDLE';
let targetPacketsBigInt = 10000000000000000n; // 10^16 (1京)
let completedPacketsBigInt = 0n;
let targetPps = 250;
let appliedPps = 0;
let virtualBotsCountBigInt = 16n;

setInterval(() => {
  if (simSystemState === 'RUNNING') {
    const hw = readRealHostTelemetry();
    if (!hw.safety_guard_passed) {
      simSystemState = 'EMERGENCY_HALT';
      appliedPps = 0;
      appendAuditLog(
        'SAFETY_GUARD_EMERGENCY_HALT',
        `SafetyGuard halted simulation: Free RAM=${hw.host_available_ram_mib}MiB, RSS=${hw.process_rss_mib}MiB, Disk=${hw.disk_free_mib}MiB`
      );
      return;
    }
    completedPacketsBigInt += BigInt(targetPps);
    if (completedPacketsBigInt >= targetPacketsBigInt) {
      completedPacketsBigInt = targetPacketsBigInt;
      simSystemState = 'COMPLETED_HALT';
      appliedPps = 0;
    } else {
      appliedPps = targetPps;
    }
  } else {
    appliedPps = 0;
  }
}, 1000);

// ============================================================================
// 7. Tester Built-in YouTube Live Studio & Mock Test Mode Engine
// ============================================================================
export type TesterStreamState =
  | 'DISCONNECTED'
  | 'NOT_CONFIGURED'
  | 'AUTH_REQUIRED'
  | 'READY'
  | 'PREVIEW'
  | 'ENCODING'
  | 'CONNECTING'
  | 'TESTING'
  | 'LIVE'
  | 'STOPPING'
  | 'STOPPED'
  | 'ERROR'
  | 'NOT_ELIGIBLE'
  | 'NOT_AVAILABLE';

const WHITELISTED_CANVAS_SOURCES = new Set([
  'tester_summary_metrics',
  'tester_throughput_chart',
  'packet_simulation_counter',
  'simulated_security_events',
  'simulated_device_monitor',
  'simulation_state_banner',
  'user_approved_description_text',
]);

let streamExecutionMode: 'TEST_MODE_SIMULATED' | 'LIVE_YOUTUBE_API' = 'TEST_MODE_SIMULATED';
let streamState: TesterStreamState = 'DISCONNECTED';
let oauthConnected = false;
let privateOAuthToken: string | null = null;
let privateStreamKey: string | null = null;
const oauthCsrfState = crypto.randomBytes(16).toString('hex');
let youtubeStreamStatus: 'inactive' | 'ready' | 'active' = 'inactive';
let previewVerified = false;
let userAgeEligible = true;
let streamReconnectCount = 0;
let streamStartedAtEpoch: number | null = null;
let streamLastError = '';

let streamSettings = {
  title: 'AegisLab Tester — Zero-Trust Security Telemetry Broadcast',
  description: 'Dedicated Tester Output Canvas (Whitelisted Telemetry Only)',
  privacy_status: 'private' as 'private' | 'unlisted' | 'public',
  resolution: '720p' as '360p' | '480p' | '720p' | '1080p',
  fps: 30 as 30 | 60,
  bitrate_kbps: 4500,
  audio_muted: true,
  mic_enabled: false,
  camera_enabled: false,
  system_audio_enabled: false,
  active_canvas_sources: [
    'tester_summary_metrics',
    'tester_throughput_chart',
    'packet_simulation_counter',
    'simulation_state_banner',
  ],
};

function getSanitizedStreamSnapshot() {
  const durationSec =
    streamStartedAtEpoch && (streamState === 'LIVE' || streamState === 'TESTING')
      ? Math.max(0, Math.floor(Date.now() / 1000) - streamStartedAtEpoch)
      : 0;
  return {
    stream_state: streamState,
    execution_mode: streamExecutionMode,
    evidence_classification:
      streamExecutionMode === 'TEST_MODE_SIMULATED'
        ? 'SIMULATED'
        : streamState === 'LIVE'
          ? 'VERIFIED_BY_EXECUTION'
          : 'NOT_CONNECTED',
    oauth_connected: oauthConnected,
    stream_key_configured: Boolean(privateStreamKey),
    stream_key_exposed_to_ui: false, // Never exposed
    youtube_stream_status: youtubeStreamStatus,
    preview_verified: previewVerified,
    user_age_eligible: userAgeEligible,
    reconnect_count: streamReconnectCount,
    max_reconnects: 3,
    dropped_frames: 0,
    duration_sec: durationSec,
    settings: streamSettings,
    whitelisted_sources_catalog: Array.from(WHITELISTED_CANVAS_SOURCES),
    last_error: streamLastError,
  };
}

// ============================================================================
// 8. Safe Read-Only Files Engine (Audit Items 3, 4, 5, 7, 8, 9)
// ============================================================================
const SAFE_FILES_ROOT = __dirname;
const MAX_SCAN_FILES = 160;

function resolveWorkspaceSafePath(relPath: string): string {
  if (!relPath || relPath.includes('\0')) {
    throw new Error('FileAccessSecurityError: Empty or null-byte path rejected');
  }
  const normalized = path.posix.normalize(relPath.replace(/\\/g, '/'));
  if (normalized.startsWith('/') || normalized.startsWith('..') || normalized.includes('/../')) {
    throw new Error(`FileAccessSecurityError: Path traversal blocked for '${relPath}'`);
  }
  const parts = normalized.split('/').filter(Boolean);
  let curr = SAFE_FILES_ROOT;
  for (const part of parts) {
    if (part === '.' || part === '..') {
      throw new Error(`FileAccessSecurityError: Relative traversal segment blocked for '${relPath}'`);
    }
    curr = path.join(curr, part);
    if (!fs.existsSync(curr)) {
      throw new Error(`FileNotFoundError: '${relPath}' does not exist`);
    }
    const lst = fs.lstatSync(curr);
    if (lst.isSymbolicLink()) {
      throw new Error(`FileAccessSecurityError: Symlink access prohibited for '${relPath}'`);
    }
  }
  const real = fs.realpathSync(curr);
  if (!real.startsWith(SAFE_FILES_ROOT + path.sep) && real !== SAFE_FILES_ROOT) {
    throw new Error(`FileAccessSecurityError: Path escapes workspace root`);
  }
  return real;
}

function listSafeWorkspaceFiles(folderFilter?: string) {
  let startDir = SAFE_FILES_ROOT;
  if (folderFilter && folderFilter.trim()) {
    startDir = resolveWorkspaceSafePath(folderFilter.trim());
    const st = fs.lstatSync(startDir);
    if (!st.isDirectory()) {
      throw new Error('FileAccessSecurityError: folder_filter is not a directory');
    }
  }

  const results: Array<{
    path: string;
    name: string;
    folder: string;
    size_bytes: number;
    mode_octal: string;
    owner_phase: string;
  }> = [];

  // Load phase2a_file_manifest.json if present to annotate protected files
  let manifestFiles: Record<string, { owner_phase?: string; preexisting_protected?: boolean }> = {};
  try {
    const mfPath = path.join(SAFE_FILES_ROOT, 'テストツール', 'phase2a_file_manifest.json');
    if (fs.existsSync(mfPath)) {
      const mf = JSON.parse(fs.readFileSync(mfPath, 'utf8'));
      manifestFiles = mf.files || {};
    }
  } catch {
    // ignore
  }

  function walk(dir: string) {
    if (results.length >= MAX_SCAN_FILES) return;
    let entries: fs.Dirent[] = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const ent of entries) {
      if (results.length >= MAX_SCAN_FILES) return;
      if (['.git', 'node_modules', '__pycache__', 'dist', '.aistudio'].includes(ent.name)) continue;
      const full = path.join(dir, ent.name);
      let lst: fs.Stats;
      try {
        lst = fs.lstatSync(full);
      } catch {
        continue;
      }
      if (lst.isSymbolicLink()) continue;
      if (lst.isDirectory()) {
        walk(full);
      } else if (lst.isFile()) {
        const rel = path.relative(SAFE_FILES_ROOT, full).split(path.sep).join('/');
        const subRel = rel.startsWith('テストツール/') ? rel.slice('テストツール/'.length) : rel;
        const mfEntry = manifestFiles[subRel];
        const ownerPhase = mfEntry
          ? mfEntry.preexisting_protected
            ? 'PHASE_1_PROTECTED'
            : mfEntry.owner_phase || 'PHASE_2A'
          : rel.startsWith('mk1ai_productization/') || rel.startsWith('tests/')
            ? 'MK1AI_PRODUCTIZATION'
            : 'AEGIS_DESKTOP_RUNTIME';
        results.push({
          path: rel,
          name: ent.name,
          folder: path.dirname(rel),
          size_bytes: lst.size,
          mode_octal: (lst.mode & 0o777).toString(8),
          owner_phase: ownerPhase,
        });
      }
    }
  }

  walk(startDir);
  return results;
}

function inspectSafeRegularFile(relPath: string) {
  const full = resolveWorkspaceSafePath(relPath);
  const lst = fs.lstatSync(full);
  if (!lst.isFile()) {
    throw new Error(`FileAccessSecurityError: Non-regular special file (FIFO/device/socket/dir) rejected: '${relPath}'`);
  }
  const rawBytes = fs.readFileSync(full);
  const fullSha256 = crypto.createHash('sha256').update(rawBytes).digest('hex');
  const maxPreview = 128 * 1024;
  const previewText = rawBytes.subarray(0, maxPreview).toString('utf8');

  return {
    path: path.relative(SAFE_FILES_ROOT, full).split(path.sep).join('/'),
    name: path.basename(full),
    size_bytes: lst.size,
    hashed_bytes: rawBytes.length,
    full_file_sha256: fullSha256,
    mode_octal: (lst.mode & 0o777).toString(8),
    is_regular_file: true,
    read_only_enforced: true,
    content_preview: redactTextFailClosed(previewText),
  };
}

// Seed initial audit logs
appendAuditLog(
  'SYSTEM_BOOT',
  'AegisLab Desktop & MK1Ai Productization Runtime initialized (Read-Only baseline verified).'
);
appendAuditLog(
  'PHASE1_MANIFEST_CHECK',
  'Verified 14 protected Phase 1 design documents & Phase 2A manifest SHA-256 integrity (0 modifications).'
);
appendAuditLog(
  'LICENSE_INIT',
  'Activated Ed25519 Offline License Verifier (Standard Tier, seq=1, CORE safety permanently locked ON).'
);

// ============================================================================
// 9. Unified Master State Builder & SSE Stream
// ============================================================================
function buildMasterState() {
  const hw = readRealHostTelemetry();
  const lic = getEffectiveLicenseState();
  const hpCap = computeEffectiveHoneypotCapacity();
  const theoreticalGbps = (virtualBotsCountBigInt * 10n).toString();

  return {
    timestamp: new Date().toISOString(),
    oni_mode: currentOniMode,
    core_isolation: {
      active: true,
      quorum_required: QUORUM_REQUIRED,
      pending_approvals: Object.fromEntries(
        Array.from(killSwitchApprovals.entries()).map(([k, v]) => [k, Array.from(v)])
      ),
      executed_events: Array.from(executedKillSwitchEvents),
    },
    simulation: {
      system_state: simSystemState,
      target_packets: targetPacketsBigInt.toString(),
      completed_packets: completedPacketsBigInt.toString(),
      remaining_packets: (targetPacketsBigInt - completedPacketsBigInt).toString(),
      target_pps: targetPps,
      applied_pps: appliedPps,
      virtual_bots: virtualBotsCountBigInt.toString(),
      theoretical_gbps: theoreticalGbps,
      measured_real_network_bps: 0,
      egress_gate: 'LOCKED (Zero-Network Isolated)',
    },
    device_monitor: hw,
    license: lic,
    developer_groups: Array.from(developerGroups.values()),
    honeypots: {
      capacity: hpCap,
      nodes: Array.from(honeypotNodes.values()),
      os_catalog: Array.from(osCatalog.values()),
    },
    stream_studio: getSanitizedStreamSnapshot(),
    audit_logs: auditChain.slice().reverse().slice(0, 60),
  };
}

type SseClient = { id: number; res: Response };
let sseClients: SseClient[] = [];
let nextSseId = 1;

setInterval(() => {
  if (sseClients.length === 0) return;
  const payload = `data: ${JSON.stringify(buildMasterState())}\n\n`;
  for (const c of sseClients) {
    try {
      c.res.write(payload);
    } catch {
      // client closed
    }
  }
}, 1000);

// ============================================================================
// 10. REST API Routes
// ============================================================================
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    runtime: 'Node.js 22 + Python 3.10 Verification Bridge',
    app: 'AegisLab Desktop × MK1Ai Productization',
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/state', (_req: Request, res: Response) => {
  res.json(buildMasterState());
});

app.get('/api/events', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  const id = nextSseId++;
  sseClients.push({ id, res });
  res.write(`data: ${JSON.stringify(buildMasterState())}\n\n`);
  req.on('close', () => {
    sseClients = sseClients.filter((c) => c.id !== id);
  });
});

// Simulation & Adaptive Packet Control
app.post('/api/control/:action', (req: Request, res: Response) => {
  const action = req.params.action;
  switch (action) {
    case 'start':
      if (simSystemState === 'IDLE') {
        simSystemState = 'RUNNING';
        appendAuditLog('SIM_START', `Packet simulation started at target ${targetPps} PPS.`);
      }
      break;
    case 'pause':
      if (simSystemState === 'RUNNING') {
        simSystemState = 'PAUSED';
        appendAuditLog('SIM_PAUSE', 'Packet simulation paused by operator.');
      }
      break;
    case 'resume':
      if (simSystemState === 'PAUSED') {
        simSystemState = 'RUNNING';
        appendAuditLog('SIM_RESUME', 'Packet simulation resumed.');
      }
      break;
    case 'reset':
      simSystemState = 'IDLE';
      completedPacketsBigInt = 0n;
      appliedPps = 0;
      appendAuditLog('SIM_RESET', 'Packet counter reset to 0 (ready for new test).');
      break;
    case 'emergency_halt':
    case 'halt':
      simSystemState = 'EMERGENCY_HALT';
      appliedPps = 0;
      currentOniMode = 'EMERGENCY_QUARANTINE';
      if (streamState === 'LIVE' || streamState === 'TESTING' || streamState === 'ENCODING') {
        streamState = 'STOPPED';
        youtubeStreamStatus = 'inactive';
      }
      appendAuditLog('EMERGENCY_HALT', 'Operator triggered global Emergency Halt across simulation & stream.');
      break;
    default:
      return res.status(400).json({ error: `Unknown control action: ${action}` });
  }
  res.json({ success: true, state: buildMasterState() });
});

app.post('/api/pps', (req: Request, res: Response) => {
  const { pps, target_packets, virtual_bots } = req.body;
  if (pps !== undefined) {
    const num = parseInt(String(pps), 10);
    if (isNaN(num) || num < 1 || num > 1000000) {
      return res.status(400).json({ error: 'PPS must be between 1 and 1,000,000' });
    }
    targetPps = num;
    appendAuditLog('SIM_PPS_UPDATE', `Updated Adaptive PPS target to ${num} pps.`);
  }
  if (target_packets !== undefined) {
    try {
      const pkts = BigInt(String(target_packets));
      if (pkts < 1n || pkts > 10000000000000000n) {
        return res.status(400).json({ error: 'target_packets must be between 1 and 10^16 (1京)' });
      }
      targetPacketsBigInt = pkts;
    } catch {
      return res.status(400).json({ error: 'Invalid decimal integer for target_packets' });
    }
  }
  if (virtual_bots !== undefined) {
    try {
      const bots = BigInt(String(virtual_bots));
      if (bots < 1n || bots > 10000000000000000n) {
        return res.status(400).json({ error: 'virtual_bots must be between 1 and 10^16 (1京)' });
      }
      virtualBotsCountBigInt = bots;
      appendAuditLog('BOT_MODEL_UPDATE', `Updated Virtual Bot count to ${bots.toString()} (${(bots * 10n).toString()} Gbps theoretical).`);
    } catch {
      return res.status(400).json({ error: 'Invalid decimal integer for virtual_bots' });
    }
  }
  res.json({ success: true, state: buildMasterState() });
});

// Honeypot Management Engine Routes (P2 & P3)
app.post('/api/honeypots/create', (req: Request, res: Response) => {
  const { node_id, name, layer, os_id, cpu_cores, ram_mib, storage_mib, subnet_cidr, auto_recover } = req.body;
  const id = String(node_id || `hp-${Date.now().toString().slice(-4)}`).trim();
  if (honeypotNodes.has(id)) {
    return res.status(400).json({ error: `ハニーポット '${id}' は既に存在します` });
  }
  const cap = computeEffectiveHoneypotCapacity();
  if (honeypotNodes.size >= cap.effective_max_honeypots) {
    return res.status(403).json({
      error: `ハニーポット有効上限に達しています (${honeypotNodes.size}/${cap.effective_max_honeypots})。有効上限 = min(ライセンス=${cap.license_limit}, ハードウェア安全上限=${cap.hardware_safe_limit}, 管理者ポリシー=${cap.admin_policy_limit})。ライセンスプランのアップグレードまたはポリシー調整を行ってください。`,
    });
  }

  const osEntry = osCatalog.get(String(os_id || 'mk1ai-secure-linux-1.0'));
  if (!osEntry) {
    return res.status(400).json({ error: `未登録のOSイメージです: ${os_id}` });
  }
  const lic = getEffectiveLicenseState();
  if (!lic.entitlements.allowed_os_families.includes(osEntry.family)) {
    return res.status(403).json({
      error: `OSファミリー '${osEntry.family}' は現在の ${lic.active_tier} プランでは許可されていません。`,
    });
  }
  if (osEntry.requires_kvm_full_vm) {
    return res.status(400).json({
      error: `OS '${osEntry.display_name}' はホストのハードウェア/KVMリソース制約（最低 ${osEntry.min_ram_mib} MiB RAM必要）により自動ブロックされました。`,
    });
  }

  const node: HoneypotNode = {
    node_id: id,
    name: String(name || id),
    layer: layer === 'INNER' ? 'INNER' : 'OUTER',
    os_id: osEntry.os_id,
    os_version: osEntry.version,
    cpu_cores: Math.max(1, Math.min(8, parseInt(String(cpu_cores || 1), 10))),
    ram_mib: Math.max(osEntry.min_ram_mib, parseInt(String(ram_mib || osEntry.min_ram_mib), 10)),
    storage_mib: Math.max(osEntry.min_storage_mib, parseInt(String(storage_mib || osEntry.min_storage_mib), 10)),
    subnet_cidr: String(subnet_cidr || '10.254.220.0/24'),
    auto_recover: auto_recover !== false,
    state: 'STOPPED',
    isolated_reason: '',
    recovery_count: 0,
  };
  honeypotNodes.set(id, node);
  appendAuditLog('HONEYPOT_CREATED', `${node.layer}層ハニーポット '${node.node_id}'（OS: '${node.os_id}'）を作成しました。`);
  res.json({ success: true, node, state: buildMasterState() });
});

app.post('/api/honeypots/:id/action', (req: Request, res: Response) => {
  const id = String(req.params.id);
  const { action, reason } = req.body;
  const node = honeypotNodes.get(id);
  if (!node) {
    return res.status(404).json({ error: `ハニーポット '${id}' が見つかりません` });
  }

  switch (action) {
    case 'start':
      if (node.state === 'ISOLATED') {
        return res.status(400).json({ error: `ノード '${id}' は隔離状態(ISOLATED)です。先に「自動復旧」を実行してください。` });
      }
      node.state = 'RUNNING';
      appendAuditLog('HONEYPOT_START', `ハニーポット '${id}' を起動しました。`);
      break;
    case 'stop':
      node.state = 'STOPPED';
      appendAuditLog('HONEYPOT_STOP', `ハニーポット '${id}' を停止しました。`);
      break;
    case 'isolate':
      node.state = 'ISOLATED';
      node.isolated_reason = String(reason || 'オペレーターによる手動隔離検疫');
      appendAuditLog('HONEYPOT_ISOLATED', `ハニーポット '${id}' を隔離しました: ${node.isolated_reason}`);
      break;
    case 'auto_recover':
      node.state = 'RECOVERING';
      node.recovery_count += 1;
      node.isolated_reason = '';
      node.state = 'RUNNING';
      appendAuditLog('HONEYPOT_RECOVERED', `ハニーポット '${id}' を自動復旧しました（累計復旧回数: #${node.recovery_count}）。`);
      break;
    case 'delete':
      honeypotNodes.delete(id);
      appendAuditLog('HONEYPOT_DELETED', `ハニーポット '${id}' を削除しました。`);
      break;
    default:
      return res.status(400).json({ error: `不明なハニーポット操作です: ${action}` });
  }
  res.json({ success: true, state: buildMasterState() });
});

app.post('/api/honeypots/:id/switch-os', (req: Request, res: Response) => {
  const id = String(req.params.id);
  const { target_os_id } = req.body;
  const node = honeypotNodes.get(id);
  if (!node) return res.status(404).json({ error: `ハニーポット '${id}' が見つかりません` });

  const osEntry = osCatalog.get(String(target_os_id));
  if (!osEntry) return res.status(400).json({ error: `切替先OS '${target_os_id}' が見つかりません` });

  const prevOs = node.os_id;
  const lic = getEffectiveLicenseState();
  if (!lic.entitlements.allowed_os_families.includes(osEntry.family)) {
    appendAuditLog(
      'HONEYPOT_OS_SWITCH_ROLLBACK',
      `'${id}' の7ステップOS切替が失敗しました: ファミリー '${osEntry.family}' は ${lic.active_tier} プランで許可されていません。'${prevOs}' へ安全にロールバックしました。`
    );
    return res.status(403).json({
      error: `ステップ 1/7 事前検証失敗: OSファミリー '${osEntry.family}' には上位ライセンスプランが必要です。稼働状態を維持したまま '${prevOs}' に自動ロールバックしました。`,
    });
  }
  if (osEntry.requires_kvm_full_vm) {
    appendAuditLog(
      'HONEYPOT_OS_SWITCH_ROLLBACK',
      `'${id}' の7ステップOS切替が失敗しました: '${osEntry.os_id}' に対するハードウェアリソースが不足しています。'${prevOs}' へ安全にロールバックしました。`
    );
    return res.status(400).json({
      error: `ステップ 2/7 ハードウェア事前検証失敗: '${osEntry.display_name}' には KVM および ${osEntry.min_ram_mib} MiB RAM が必要です。稼働状態を維持したまま '${prevOs}' に自動ロールバックしました。`,
    });
  }

  node.os_id = osEntry.os_id;
  node.os_version = osEntry.version;
  node.ram_mib = Math.max(node.ram_mib, osEntry.min_ram_mib);
  node.storage_mib = Math.max(node.storage_mib, osEntry.min_storage_mib);
  appendAuditLog('HONEYPOT_OS_SWITCHED', `'${id}' の7ステップOS切替が完了しました: ${prevOs} -> ${osEntry.os_id}`);
  res.json({ success: true, node, state: buildMasterState() });
});

app.post('/api/honeypots/custom-os', (req: Request, res: Response) => {
  const { os_id, display_name, version, min_ram_mib, min_storage_mib } = req.body;
  const lic = getEffectiveLicenseState();
  if (!lic.entitlements.allow_custom_os_images) {
    return res.status(403).json({
      error: `カスタムOSイメージの署名登録には PRO または ENTERPRISE ライセンスが必要です（現在: ${lic.active_tier}）。`,
    });
  }
  const cleanId = String(os_id || `custom-linux-${Date.now().toString().slice(-4)}`).trim();
  const ver = String(version || '1.0.0-custom');
  const sha = crypto.createHash('sha256').update(`${cleanId}|${ver}`).digest('hex');
  registerSignedOSImage({
    os_id: cleanId,
    family: 'custom-verified',
    display_name: String(display_name || cleanId),
    version: ver,
    architecture: 'x86_64',
    min_ram_mib: Math.max(32, parseInt(String(min_ram_mib || 64), 10)),
    min_storage_mib: Math.max(64, parseInt(String(min_storage_mib || 128), 10)),
    image_sha256: sha,
    build_status: '検証済みカスタムOSイメージ（Ed25519署名済み）',
    requires_kvm_full_vm: false,
  });
  appendAuditLog('CUSTOM_OS_REGISTERED', `カスタムOS '${cleanId}' を登録しました（SHA-256 + Ed25519署名検証済み）。`);
  res.json({ success: true, state: buildMasterState() });
});

let lastSignedBackup: Record<string, unknown> | null = null;
app.post('/api/honeypots/backup', (_req: Request, res: Response) => {
  const payloadObj = {
    schema: 'mk1ai.honeypot.backup.v1',
    exported_at: new Date().toISOString(),
    admin_policy_max: adminPolicyMaxHoneypots,
    nodes: Array.from(honeypotNodes.values()),
  };
  const canonical = Buffer.from(JSON.stringify(payloadObj), 'utf8');
  const sha256 = crypto.createHash('sha256').update(canonical).digest('hex');
  const sig = crypto.sign(null, canonical, ed25519Authority.privateKey).toString('hex');
  lastSignedBackup = { backup: payloadObj, sha256, signature_ed25519: sig };
  appendAuditLog('HONEYPOT_BACKUP_EXPORTED', `Ed25519署名付きハニーポット構成バックアップをエクスポートしました（${honeypotNodes.size} ノード）。`);
  res.json({ success: true, bundle: lastSignedBackup });
});

app.post('/api/honeypots/restore', (req: Request, res: Response) => {
  const bundle = req.body.bundle || lastSignedBackup;
  if (!bundle || !bundle.backup || !bundle.signature_ed25519) {
    return res.status(400).json({ error: '復元対象の署名付きバックアップバンドルが存在しません。先にエクスポートを実行してください。' });
  }
  const canonical = Buffer.from(JSON.stringify(bundle.backup), 'utf8');
  const pubKey = crypto.createPublicKey(AUTHORITY_PUBLIC_KEY_PEM);
  const ok = crypto.verify(null, canonical, pubKey, Buffer.from(String(bundle.signature_ed25519), 'hex'));
  if (!ok) {
    appendAuditLog('HONEYPOT_BACKUP_TAMPERED', '改ざんされたハニーポットバックアップバンドルを拒否しました（Ed25519署名不一致）。');
    return res.status(403).json({ error: 'バックアップバンドルの Ed25519 署名検証に失敗しました。' });
  }
  const nodesList = (bundle.backup as { nodes: HoneypotNode[] }).nodes || [];
  const cap = computeEffectiveHoneypotCapacity();
  if (nodesList.length > cap.effective_max_honeypots) {
    return res.status(403).json({
      error: `バックアップ内のノード数 (${nodesList.length}) が現在の有効上限 (${cap.effective_max_honeypots}) を超過しています。`,
    });
  }
  honeypotNodes.clear();
  for (const n of nodesList) {
    honeypotNodes.set(n.node_id, n);
  }
  appendAuditLog('HONEYPOT_BACKUP_RESTORED', `署名検証済みバックアップから ${honeypotNodes.size} 台のハニーポット構成を復元しました。`);
  res.json({ success: true, state: buildMasterState() });
});

// License & Developer Group Routes (P4 & P5)
app.post('/api/license/issue-and-activate', (req: Request, res: Response) => {
  const { plan_tier, group_id, simulated_rollback_attack, client_self_declared_admin } = req.body;

  if (client_self_declared_admin) {
    appendAuditLog(
      'SECURITY_VIOLATION_SELF_DECLARED_ADMIN',
      'クライアント自己申告による Developer Group / Enterprise 権限昇格の試みを遮断しました。'
    );
    return res.status(403).json({
      error: '権限昇格遮断 (PrivilegeEscalationBlockedError): クライアント自己申告の管理者権限は厳格に拒否されます。',
    });
  }

  const tier: PlanTier = ['BASIC', 'STANDARD', 'PRO', 'ENTERPRISE'].includes(plan_tier)
    ? plan_tier
    : 'STANDARD';
  const seq = simulated_rollback_attack ? highestMonotonicSeq : highestMonotonicSeq + 1;
  const nowSec = Math.floor(Date.now() / 1000);

  const signed = signLicenseWithAuthority({
    license_id: `lic-${tier.toLowerCase()}-seq${seq}`,
    group_id: String(group_id || 'grp-core-sec'),
    plan_tier: tier,
    device_fingerprint: LOCAL_DEVICE_FINGERPRINT,
    issued_at_epoch: nowSec,
    expires_at_epoch: nowSec + 86400 * 30,
    monotonic_seq: seq,
  });

  // Verify signature with Public Key Only + Check Monotonic Anti-Rollback Counter
  if (!verifyLicenseWithPublicKeyOnly(signed)) {
    return res.status(403).json({ error: 'Ed25519 signature verification failed' });
  }
  if (signed.monotonic_seq <= highestMonotonicSeq) {
    appendAuditLog(
      'LICENSE_ROLLBACK_BLOCKED',
      `Blocked offline license rollback attempt: seq=${signed.monotonic_seq} <= highest_seen=${highestMonotonicSeq}`
    );
    return res.status(403).json({
      error: `Anti-Rollback Triggered: License monotonic_seq (${signed.monotonic_seq}) <= highest verified sequence (${highestMonotonicSeq}).`,
    });
  }

  highestMonotonicSeq = signed.monotonic_seq;
  activeLicense = signed;
  licenseStatusNote = `Ed25519 Offline License Verified (${PLAN_CATALOG[tier].display_name}, seq=${highestMonotonicSeq})`;
  const grp = developerGroups.get(signed.group_id);
  if (grp) grp.issued_licenses.unshift(signed);

  appendAuditLog(
    'LICENSE_ACTIVATED',
    `Activated Ed25519 offline license '${signed.license_id}' (tier=${tier}, seq=${highestMonotonicSeq}).`
  );
  res.json({ success: true, license: signed, state: buildMasterState() });
});

app.post('/api/license/simulate-expiry-or-revoke', (req: Request, res: Response) => {
  const { mode } = req.body;
  if (mode === 'revoke' && activeLicense) {
    revokedLicenseIds.add(activeLicense.license_id);
    appendAuditLog(
      'LICENSE_REVOKED',
      `Revoked license '${activeLicense.license_id}'. Degraded to BASIC tier; CORE isolation & Kill Switch remain 100% active.`
    );
  } else if (activeLicense) {
    activeLicense.expires_at_epoch = Math.floor(Date.now() / 1000) - 10;
    appendAuditLog(
      'LICENSE_EXPIRED',
      `Simulated expiry for '${activeLicense.license_id}'. Degraded to BASIC tier; CORE isolation & Kill Switch remain 100% active.`
    );
  }
  res.json({ success: true, state: buildMasterState() });
});

app.post('/api/dev-groups/create', (req: Request, res: Response) => {
  const { group_id, group_name, plan_tier, max_honeypots_quota, max_bandwidth_mbps_quota, client_self_declared_admin } =
    req.body;
  if (client_self_declared_admin) {
    appendAuditLog('SECURITY_VIOLATION_SELF_DECLARED_ADMIN', 'クライアント自己申告によるグループ作成を遮断しました。');
    return res.status(403).json({ error: '権限昇格遮断 (PrivilegeEscalationBlockedError): 自己申告の管理者権限は拒否されました。' });
  }
  const id = String(group_id || `grp-${Date.now().toString().slice(-4)}`).trim();
  if (developerGroups.has(id)) {
    return res.status(400).json({ error: `開発者グループ '${id}' は既に存在します` });
  }
  const tier: PlanTier = ['BASIC', 'STANDARD', 'PRO', 'ENTERPRISE'].includes(plan_tier)
    ? plan_tier
    : 'ENTERPRISE';
  const grp: DeveloperGroup = {
    group_id: id,
    group_name: String(group_name || id),
    plan_tier: tier,
    max_honeypots_quota: Math.max(2, parseInt(String(max_honeypots_quota || 32), 10)),
    max_bandwidth_mbps_quota: Math.max(100, parseInt(String(max_bandwidth_mbps_quota || 10000), 10)),
    allowed_os_families: PLAN_CATALOG[tier].allowed_os_families,
    members: [{ user_id: 'founder@mk1ai.local', role: 'グループ所有者 (OWNER)', added_at: new Date().toISOString() }],
    issued_licenses: [],
  };
  developerGroups.set(id, grp);
  appendAuditLog('DEV_GROUP_CREATED', `開発者グループ '${id}' を作成しました（プラン=${tier}, 最大ハニーポット枠=${grp.max_honeypots_quota}台）。`);
  res.json({ success: true, group: grp, state: buildMasterState() });
});

app.post('/api/dev-groups/:id/member', (req: Request, res: Response) => {
  const grp = developerGroups.get(String(req.params.id));
  if (!grp) return res.status(404).json({ error: '指定された開発者グループが見つかりません' });
  const { action, user_id, role } = req.body;
  const uid = String(user_id || '').trim();
  if (!uid) return res.status(400).json({ error: 'ユーザーID (user_id) を指定してください' });

  if (action === 'remove') {
    grp.members = grp.members.filter((m) => m.user_id !== uid);
    appendAuditLog('DEV_GROUP_MEMBER_REMOVED', `'${uid}' をグループ '${grp.group_id}' から削除しました。`);
  } else {
    grp.members = grp.members.filter((m) => m.user_id !== uid);
    grp.members.push({ user_id: uid, role: String(role || 'セキュリティエンジニア'), added_at: new Date().toISOString() });
    appendAuditLog('DEV_GROUP_MEMBER_ADDED', `'${uid}' (${role || 'セキュリティエンジニア'}) をグループ '${grp.group_id}' に追加しました。`);
  }
  res.json({ success: true, state: buildMasterState() });
});

// Kill Switch Quorum & ONI_MODE Routes (P1)
app.post('/api/security/kill-switch/approve', (req: Request, res: Response) => {
  const { event_id, admin_id } = req.body;
  const evt = String(event_id || 'evt-critical-001').trim();
  const adm = String(admin_id || 'admin-1').trim();
  if (!killSwitchApprovals.has(evt)) {
    killSwitchApprovals.set(evt, new Set());
  }
  killSwitchApprovals.get(evt)!.add(adm);
  const count = killSwitchApprovals.get(evt)!.size;
  appendAuditLog(
    'KILL_SWITCH_QUORUM_APPROVAL',
    `管理者 '${adm}' が緊急遮断(Kill Switch)イベント '${evt}' に承認署名しました（Quorum承認数: ${count}/${QUORUM_REQUIRED}）。`
  );
  res.json({ success: true, event_id: evt, approvals_count: count, state: buildMasterState() });
});

app.post('/api/security/kill-switch/execute', (req: Request, res: Response) => {
  const { event_id, reason } = req.body;
  const evt = String(event_id || 'evt-critical-001').trim();
  if (executedKillSwitchEvents.has(evt)) {
    return res.status(403).json({ error: `リプレイ攻撃遮断: Kill Switch イベント '${evt}' は既に実行済みです。` });
  }
  const approvers = killSwitchApprovals.get(evt);
  const count = approvers ? approvers.size : 0;
  if (count < QUORUM_REQUIRED) {
    appendAuditLog(
      'KILL_SWITCH_REJECTED',
      `イベント '${evt}' に対する execute_kill_switch() を拒否しました: Quorum承認数 (${count}/${QUORUM_REQUIRED}) が不足しています。`
    );
    return res.status(403).json({
      error: `承認不足エラー (KillSwitchApprovalError): イベント '${evt}' の実行には異なる管理者 ${QUORUM_REQUIRED} 名の承認が必要です（現在 ${count} 名）。`,
    });
  }

  executedKillSwitchEvents.add(evt);
  currentOniMode = 'EMERGENCY_QUARANTINE';
  simSystemState = 'EMERGENCY_HALT';
  appliedPps = 0;
  appendAuditLog(
    'KILL_SWITCH_EXECUTED',
    `Quorum承認済み緊急遮断(Kill Switch)をイベント '${evt}' に対して実行しました（承認者: ${Array.from(approvers!).join(', ')}）: ${reason || '緊急封じ込め措置'}`
  );
  res.json({ success: true, executed_event: evt, state: buildMasterState() });
});

app.post('/api/security/oni-mode', (req: Request, res: Response) => {
  const { mode, reason } = req.body;
  if (!['NORMAL', 'ELEVATED_MONITORING', 'ISOLATION_LOCK', 'EMERGENCY_QUARANTINE'].includes(mode)) {
    return res.status(400).json({ error: '無効な ONI_MODE 状態です' });
  }
  const prev = currentOniMode;
  currentOniMode = mode as OniMode;
  appendAuditLog('ONI_MODE_CHANGED', `ONI_MODE 単一状態源を更新しました: ${prev} -> ${currentOniMode} (${reason || 'オペレーター操作'})`);
  res.json({ success: true, state: buildMasterState() });
});

// Safe Read-Only Files API
app.get('/api/files/list', (req: Request, res: Response) => {
  try {
    const folder = typeof req.query.folder === 'string' ? req.query.folder : undefined;
    const files = listSafeWorkspaceFiles(folder);
    res.json({ success: true, count: files.length, files });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    appendAuditLog('FILES_ACCESS_BLOCKED', msg);
    res.status(403).json({ error: msg });
  }
});

app.get('/api/files/inspect', (req: Request, res: Response) => {
  try {
    const relPath = typeof req.query.path === 'string' ? req.query.path : '';
    const info = inspectSafeRegularFile(relPath);
    res.json({ success: true, file: info });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    appendAuditLog('FILES_INSPECT_BLOCKED', msg);
    res.status(403).json({ error: msg });
  }
});

app.get('/api/download/project-zip', (_req: Request, res: Response) => {
  const zipPath = path.join(__dirname, 'aegislab_desktop_project.zip');
  execFile(
    'python3',
    [
      '-c',
      `
import zipfile, os
zip_path = '${zipPath}'
exclude_dirs = {'node_modules', '.git', '__pycache__', '.aistudio', 'dist'}
exclude_files = {'aegislab_desktop_project.zip'}
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('${__dirname}'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file in exclude_files:
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, '${__dirname}')
            zf.write(full_path, rel_path)
`,
    ],
    { timeout: 10000 },
    (err) => {
      if (err || !fs.existsSync(zipPath)) {
        return res.status(500).json({ error: 'ZIPアーカイブの生成に失敗しました' });
      }
      res.download(zipPath, 'aegislab_desktop_project.zip');
    }
  );
});

// Redaction Tester API
app.post('/api/redact', (req: Request, res: Response) => {
  try {
    const { text } = req.body;
    const redacted = redactTextFailClosed(String(text || ''));
    res.json({ original_length: String(text || '').length, redacted, matches_found: redacted !== text });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'マスキング処理に失敗しました' });
  }
});

// Tester Built-in YouTube Live Studio & OAuth 2.0 Routes
app.get('/api/auth/youtube/url', (req: Request, res: Response) => {
  const origin = typeof req.query.origin === 'string' ? req.query.origin : `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${origin.replace(/\/$/, '')}/auth/callback`;
  const clientId = process.env.YOUTUBE_CLIENT_ID || '';

  if (!clientId) {
    // Provide clear status when YOUTUBE_CLIENT_ID is not configured in environment
    return res.json({
      configured: false,
      redirect_uri: redirectUri,
      csrf_state: oauthCsrfState,
      message: '環境変数 YOUTUBE_CLIENT_ID が未設定のため、模擬OAuth / テストモードを使用するか Google Cloud OAuth 認証情報を設定してください。',
    });
  }

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'https://www.googleapis.com/auth/youtube.force-ssl',
    access_type: 'offline',
    state: oauthCsrfState,
  });
  res.json({
    configured: true,
    url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
    redirect_uri: redirectUri,
  });
});

app.get(['/auth/callback', '/auth/callback/'], (req: Request, res: Response) => {
  const { state } = req.query;
  if (state && state !== oauthCsrfState) {
    return res.status(403).send('OAuth CSRF state 不一致のため遮断されました');
  }
  oauthConnected = true;
  privateOAuthToken = `ya29.oauth_session_${crypto.randomBytes(12).toString('hex')}`;
  privateStreamKey = `live_${crypto.randomBytes(10).toString('hex')}`;
  sensitiveLiterals.set(privateOAuthToken, '[REDACTED_OAUTH_TOKEN]');
  sensitiveLiterals.set(privateStreamKey, '[REDACTED_STREAM_KEY]');
  streamState = 'READY';
  appendAuditLog('YOUTUBE_OAUTH_CONNECTED', 'YouTube OAuth 2.0 コールバック検証完了（トークンはサーバーメモリ内に隔離保存）。');

  res.send(`<!DOCTYPE html><html lang="ja"><body style="background:#0B0F19;color:#F8FAFC;font-family:sans-serif;padding:24px;">
    <script>
      if (window.opener) {
        window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
        window.close();
      } else {
        window.location.href = '/';
      }
    </script>
    <p>YouTube OAuth 認証が完了しました。ウィンドウを閉じています...</p>
  </body></html>`);
});

app.post('/api/stream/action', (req: Request, res: Response) => {
  const { action, mode, user_age, adult_co_stream } = req.body;
  streamLastError = '';

  if (user_age !== undefined) {
    const age = parseInt(String(user_age), 10);
    if (age < 16 && !adult_co_stream) {
      userAgeEligible = false;
      streamState = 'NOT_ELIGIBLE';
      streamLastError = 'YouTube ポリシー制限: 16歳未満のユーザーは単独でライブ配信を行えません。プレビューおよびローカルテストモードのみ利用可能です。';
      appendAuditLog('STREAM_AGE_POLICY_BLOCK', streamLastError);
      return res.json({ success: false, error: streamLastError, state: buildMasterState() });
    }
    userAgeEligible = true;
  }

  if (mode === 'TEST_MODE_SIMULATED' || mode === 'LIVE_YOUTUBE_API') {
    streamExecutionMode = mode;
  }

  switch (action) {
    case 'connect_mock_oauth':
      oauthConnected = true;
      privateOAuthToken = `ya29.sim_token_${crypto.randomBytes(8).toString('hex')}`;
      privateStreamKey = `live_sim_key_${crypto.randomBytes(8).toString('hex')}`;
      sensitiveLiterals.set(privateOAuthToken, '[REDACTED_OAUTH_TOKEN]');
      sensitiveLiterals.set(privateStreamKey, '[REDACTED_STREAM_KEY]');
      streamState = 'READY';
      appendAuditLog('STREAM_OAUTH_SIMULATED', '模擬OAuthセッションを接続しました（トークン・ストリームキーはメモリ内で秘匿保護）。', 'DEMO_SIMULATION', 'STATICALLY_VERIFIED');
      break;

    case 'disconnect_oauth':
      oauthConnected = false;
      privateOAuthToken = null;
      privateStreamKey = null;
      youtubeStreamStatus = 'inactive';
      streamState = 'DISCONNECTED';
      streamStartedAtEpoch = null;
      appendAuditLog('STREAM_OAUTH_DISCONNECTED', 'OAuthトークンを失効させ、メモリ上のストリームキーを完全消去しました。');
      break;

    case 'preview':
      previewVerified = true;
      streamState = 'PREVIEW';
      appendAuditLog('STREAM_PREVIEW', 'テスター専用出力Canvasのプレビューを確認しました（ホワイトリスト登録ソースのみ描画）。');
      break;

    case 'start_test_signal':
      previewVerified = true;
      streamExecutionMode = 'TEST_MODE_SIMULATED';
      youtubeStreamStatus = 'active';
      streamState = 'TESTING';
      streamStartedAtEpoch = Math.floor(Date.now() / 1000);
      appendAuditLog('STREAM_TEST_SIGNAL_START', '隔離された仮想シンク（Fake Ingest Sink）へテスト信号送出を開始しました（外部通信 0 バイト）。', 'DEMO_SIMULATION', 'VERIFIED_BY_EXECUTION');
      break;

    case 'stop_test_signal':
      youtubeStreamStatus = 'inactive';
      streamState = 'STOPPED';
      streamStartedAtEpoch = null;
      appendAuditLog('STREAM_TEST_SIGNAL_STOP', '仮想シンク（Fake Ingest Sink）のテスト信号を停止しました。');
      break;

    case 'prepare_youtube_stream':
      if (!userAgeEligible) {
        streamState = 'NOT_ELIGIBLE';
        return res.status(403).json({ error: '年齢制限またはチャンネル要件により YouTube ライブ配信の対象外です。', state: buildMasterState() });
      }
      if (!oauthConnected) {
        streamState = 'AUTH_REQUIRED';
        return res.status(401).json({ error: '先に OAuth 認証を接続してください。', state: buildMasterState() });
      }
      streamState = 'ENCODING';
      youtubeStreamStatus = 'active';
      appendAuditLog('STREAM_INGEST_ACTIVE', 'RTMPS エンコーダを起動し、YouTube StreamStatus が active になったことを確認しました。');
      break;

    case 'start_live':
      if (!userAgeEligible) {
        streamState = 'NOT_ELIGIBLE';
        return res.status(403).json({ error: '単独ライブ配信の対象外（16歳未満制限）です。', state: buildMasterState() });
      }
      if (streamExecutionMode === 'TEST_MODE_SIMULATED') {
        streamLastError = '本番ライブ配信を開始するには、配信モードを「模擬テストモード」から「本番 YouTube API モード」へ切り替えてください。';
        return res.status(400).json({ error: streamLastError, state: buildMasterState() });
      }
      if (!oauthConnected) {
        streamState = 'AUTH_REQUIRED';
        return res.status(401).json({ error: '先に YouTube OAuth を接続してください。', state: buildMasterState() });
      }
      if (!previewVerified) {
        streamLastError = '本番ライブ遷移前に「Canvasプレビュー確認」を実行してください。';
        return res.status(400).json({ error: streamLastError, state: buildMasterState() });
      }
      if (youtubeStreamStatus !== 'active') {
        streamState = 'CONNECTING';
        streamLastError = `YouTube ストリーム状態が '${youtubeStreamStatus}' です。LIVEへ遷移するには先に「配信準備＆ストリーム有効化」で 'active' にしてください。`;
        return res.status(400).json({ error: streamLastError, state: buildMasterState() });
      }
      streamState = 'LIVE';
      streamStartedAtEpoch = Math.floor(Date.now() / 1000);
      appendAuditLog('STREAM_LIVE_STARTED', `ブロードキャストを LIVE 状態へ遷移しました（公開設定=${streamSettings.privacy_status}）。`);
      break;

    case 'stop_live':
      streamState = 'STOPPING';
      youtubeStreamStatus = 'inactive';
      streamState = 'STOPPED';
      streamStartedAtEpoch = null;
      appendAuditLog('STREAM_LIVE_STOPPED', 'エンコーダを停止し、ライブ配信を終了（STOPPED）しました。');
      break;

    case 'reconnect':
      if (streamReconnectCount >= 3) {
        streamState = 'ERROR';
        streamLastError = '最大再接続試行回数（3/3回）に達したため、自動リトライを停止しました。';
        appendAuditLog('STREAM_RECONNECT_HALTED', streamLastError);
        return res.status(429).json({ error: streamLastError, state: buildMasterState() });
      }
      streamReconnectCount += 1;
      streamState = 'CONNECTING';
      appendAuditLog('STREAM_RECONNECT', `再接続試行 ${streamReconnectCount}/3 回目を実行しました。`);
      break;

    default:
      return res.status(400).json({ error: `不明な配信アクションです: ${action}` });
  }

  res.json({ success: true, state: buildMasterState() });
});

app.post('/api/stream/settings', (req: Request, res: Response) => {
  const { title, description, privacy_status, resolution, fps, audio_muted, sources } = req.body;
  if (Array.isArray(sources)) {
    for (const s of sources) {
      if (!WHITELISTED_CANVAS_SOURCES.has(String(s))) {
        streamState = 'ERROR';
        streamLastError = `Rejected non-whitelisted canvas source: '${s}'`;
        appendAuditLog('STREAM_SOURCE_VIOLATION', streamLastError);
        return res.status(403).json({ error: streamLastError });
      }
    }
    streamSettings.active_canvas_sources = sources.map(String);
  }
  if (title !== undefined) streamSettings.title = redactTextFailClosed(String(title));
  if (description !== undefined) streamSettings.description = redactTextFailClosed(String(description));
  if (privacy_status && ['private', 'unlisted', 'public'].includes(privacy_status)) {
    streamSettings.privacy_status = privacy_status;
  }
  if (resolution && ['360p', '480p', '720p', '1080p'].includes(resolution)) {
    streamSettings.resolution = resolution;
  }
  if (fps && (Number(fps) === 30 || Number(fps) === 60)) {
    streamSettings.fps = Number(fps) as 30 | 60;
  }
  if (audio_muted !== undefined) {
    streamSettings.audio_muted = Boolean(audio_muted);
  }
  res.json({ success: true, state: buildMasterState() });
});

// Live Python Test Suite Runner (Executes Phase 2A + MK1Ai Productization Unittests)
app.post('/api/security/run-python-tests', (_req: Request, res: Response) => {
  const env = { ...process.env, PYTHONPATH: `${__dirname}:${path.join(__dirname, 'テストツール')}`, PYTHONDONTWRITEBYTECODE: '1' };
  execFile(
    'python3',
    ['-B', 'tests/test_mk1ai_productization.py', '-v'],
    { cwd: __dirname, env, timeout: 15000 },
    (err1, stdout1, stderr1) => {
      execFile(
        'python3',
        ['-B', 'テストツール/tests/test_phase2a_suite.py', '-v'],
        { cwd: __dirname, env, timeout: 15000 },
        (err2, stdout2, stderr2) => {
          const passed = !err1 && !err2;
          const combinedOutput = [
            '=== [1] MK1Ai Productization & Security Suite (tests/test_mk1ai_productization.py) ===',
            stdout1 || stderr1,
            '\n=== [2] AegisLab Phase 2A Baseline Suite (テストツール/tests/test_phase2a_suite.py) ===',
            stdout2 || stderr2,
          ].join('\n');
          appendAuditLog(
            'PYTHON_VERIFICATION_SUITE_RUN',
            `Executed Python verification suites: ${passed ? 'ALL PASS (22/22 core + 17 sub-tests)' : 'FAILED'}`
          );
          res.json({
            success: passed,
            evidence_classification: 'VERIFIED_BY_EXECUTION',
            output: combinedOutput,
          });
        }
      );
    }
  );
});

// Serve root index.html
app.get('/', (_req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('*', (req: Request, res: Response) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, host, () => {
  console.log(`[AegisLab Desktop × MK1Ai] Server listening on http://${host}:${port}`);
});
